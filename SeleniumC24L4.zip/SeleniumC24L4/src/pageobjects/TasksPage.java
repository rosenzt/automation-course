package pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TasksPage extends BasePage {
	@FindBy(css="#task")
	private WebElement taskField;
	@FindBy(css="#newtask_submit")
	private WebElement btnSubmit;
	@FindBy(css="#newtask_adv > span")
	private WebElement btnAdvTask;
	
	public TasksPage(WebDriver driver) {
		super(driver);
	}

	public void addSimpleTask(String task) {
		fillText(taskField, task);
		click(btnSubmit);
	}
	
	public void openAdvTask() {
		click(btnAdvTask);
	}
	
}
