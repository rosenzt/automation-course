package Inheritance.Question2;

public class Gorilla extends Monkeys {

    public void howManyLegs() {
        System.out.println("Two, or four, depends on how you look at it :-)");
    }
}
