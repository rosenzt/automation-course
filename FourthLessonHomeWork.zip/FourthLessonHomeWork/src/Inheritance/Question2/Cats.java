package Inheritance.Question2;

public class Cats extends Animal {
}
