package Inheritance.Question2;

public class Anaconda extends Snakes {

    public void howManyLegs() {
        System.out.println("An Anaconda has no legs.");
    }
}
