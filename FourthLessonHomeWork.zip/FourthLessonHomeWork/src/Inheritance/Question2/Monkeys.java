package Inheritance.Question2;

public class Monkeys extends Animal {
}
