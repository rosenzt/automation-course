package Inheritance.Question2;

public class Reptiles extends Animal {
}
