package Inheritance.Question2;

public class Mammels extends Animal {
}
