package Inheritance.Question2;

public class Animal {

    public void howDoYouLive() {
        System.out.println("I breath oxygen.");
    }

    public void howManyLegs() {
        System.out.println("This question is too general.");
    }
}
