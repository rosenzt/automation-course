package Inheritance.Question2;

public class Anole extends Lizards {

    public void howManyLegs() {
        System.out.println("An Anole has four legs.");
    }
}
