package Inheritance.Question2;

public class Lizards extends Reptiles {
}
