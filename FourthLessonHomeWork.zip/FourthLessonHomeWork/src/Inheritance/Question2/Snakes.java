package Inheritance.Question2;

public class Snakes extends Reptiles {
}
