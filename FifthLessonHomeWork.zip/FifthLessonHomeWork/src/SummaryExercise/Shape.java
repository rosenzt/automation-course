package SummaryExercise;

public class Shape {

    public double calcArea() {
        return 0;
    }

    public double calcCircumferences() {
        return 0;
    }
}
